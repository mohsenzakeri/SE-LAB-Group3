function change_color	(elmnt,clr) {
    elmnt.style.color = clr;
    elmnt.style.background_color = clr;
}

;
